# 🤖 Azure LangChain Agent with SerpAPI

This project is a FastAPI-based LangChain agent that uses Azure OpenAI (`gpt-35-turbo`) along with SerpAPI to answer user queries using live web search. It is ready to deploy on Azure AI (Foundry / Azure ML Online Endpoints).

...

(Markdown trimmed here for brevity, full content is added in actual file)